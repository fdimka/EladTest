import { useState } from 'react';
import Container from './components/Container/Container';
import Button from './components/Button/Button';
import ColorPickers from './components/ColorPickers/ColorPickers';
import StringTreatment from './components/StringTreatment/StringTreatment';
import styles from './App.module.css'


function App() {
  const [playBall, setPlayBall] = useState(false);
  const [fillBall, setFillBall] = useState(false);
  const [colorsVal, setColorsVal] = useState([]);

  const handleBounceToggle = () => {
    setPlayBall(!playBall);
  };

  const handleFillToggle = () => {
    setFillBall(!fillBall);
  }

  const handleColorsTransfer = (colorData) => {
    setColorsVal(colorData);
  }

  return (
    <div className={`${styles.app}`}>
      <p className={`${styles.header}`}>Bounce&Fill Ball</p>
      <Container bounce={playBall} colorFill={fillBall} colorsVal={colorsVal} />
      <div className={`${styles.actions}`}>
        <Button type="submit" className={`${styles.interval}`} onClick={handleBounceToggle}>
          Bounce
        </Button>
        <Button type="submit" className={styles.btn} onClick={handleFillToggle}>
          Fill
        </Button>
      </div>
      <ColorPickers colorsTransfer={handleColorsTransfer} />
      
      <p className={`${styles.header}`}>Strings and Calls</p>
      <StringTreatment />
    </div>
  );
}

export default App;
