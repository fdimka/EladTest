import axios from 'axios'

const getAllItems = (url) =>
{
    return axios.get(url)
}

// eslint-disable-next-line import/no-anonymous-default-export
export default {getAllItems}