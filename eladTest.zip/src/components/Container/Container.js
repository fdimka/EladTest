import React from 'react';
import Ball from '../Ball/Ball';
import styles from './Container.module.css';

const Container = props => {
    return (
        <div className={`${styles.container}`}>
            <Ball bounce={props.bounce} colorFill={props.colorFill} colorsVal={props.colorsVal}/>
        </div>
    );
};

export default Container;