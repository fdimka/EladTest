import utils from '../../utils';
import { useState, useEffect } from 'react';
import styles from './StringTreatment.module.css'

const URL = 'https://jsonplaceholder.typicode.com';

const StringTreatment = props => {

    const [fetchedData, setFetchedData] = useState([]);

    useEffect(() => {
        const fetchData = async () => {
            const result = await utils.getAllItems(URL + '/todos/');
            setFetchedData(result.data);
        }
        fetchData();
    }, []);

    if (fetchedData.length === 0) return null;

    let items = fetchedData.filter(item => item.title.toLowerCase().startsWith('s'));

    const header = Object.keys(items[0]);
    const renderTableHeader = header.map((key, index) => {
        return <th key={index}>{key.toUpperCase()}</th>;
    });

    const renderTableData = items.map((item, index) => {
        return (
            <tr key={index} className={`${item.title.toLowerCase().endsWith('e') ? styles.yellowr :""} `}>
                <td>{item.userId}</td>
                <td>{item.id}</td>
                <td>{item.title}</td>
                <td>{item.completed ? 'true' : 'false'}</td>
            </tr>
        )
    });

    return (
        <div>
            <table className={`${styles['table-conf']}`}>
                <tbody>
                    <tr>{renderTableHeader}</tr>
                    {renderTableData}
                </tbody>
            </table>
        </div>
    )
}
export default StringTreatment;