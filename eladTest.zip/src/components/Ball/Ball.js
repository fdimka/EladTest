import React from 'react';
import styles from './Ball.module.css';

const Ball = props => {

    props.colorsVal.map((color, index) => {
        document.documentElement.style.setProperty('--ball-color' + index, color);
        return null;
    });

    return (
        <div className={`${styles.ball} ${props.bounce ? styles.anim : props.colorFill ? styles.fillcolor : ""} `}  ></div>
    );
};

export default Ball;

