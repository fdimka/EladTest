import React, { useState, useEffect } from 'react';
import styles from './ColorPickers.module.css';

const ColorPickers = props => {
    const colorValuesArr = ['#FF0000', '#00FF00', '#0000FF'];

    const [colorsValue, setColorsValue] = useState(colorValuesArr);
  
    useEffect(() => {
            props.colorsTransfer(colorValuesArr);  
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    const handleColorChange = (e) => {
        const newColorValue = [...colorsValue];
        newColorValue[e.target.id] = e.target.value;
        setColorsValue(newColorValue);
        props.colorsTransfer(newColorValue);
    };

    return (
        <div className={`${styles['e-position']}`}>
            {
                colorsValue.map((color, index) => {
                    return <input key={index} type="color" value={color} id={index} onChange={handleColorChange} />
                })
            }
        </div>
    );
};

export default ColorPickers;
